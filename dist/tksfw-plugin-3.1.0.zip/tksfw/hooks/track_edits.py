#!/usr/bin/env python3
"""Edit tracker + ledger validator (PostToolUse / UserPromptSubmit) — harness-neutral.

Detects edits by HASHING the watched set (workarea ledgers, deliverables registered in
deliverables.yaml, framework files) before/after each tool call and journals the delta to
`.agents/workarea/.hook-state/journal.jsonl`. It never reads `tool_input.file_path` (Claude Code
only) or the transcript (unstable in both harnesses), so the same script behaves identically
under Codex CLI (`apply_patch`, shell writes, MCP tools) and Claude Code (`Edit`/`Write`, `Bash`,
MCP tools), and also sees writes made by subagents and by Python helpers.

Phases (`--phase`):
  tool    (default) PostToolUse. Journals the delta attributed to this tool call and, when a
          workarea YAML ledger changed, runs the yaml-log-entry validator on exactly those files.
          On a schema/parse failure it exits 2 with the report on stderr — both harnesses feed
          that back to the model as the tool result — so a malformed entry never silently
          persists. A delegation tool call (Agent/Task/spawn_agent) is journaled even when
          nothing changed, for the Stop-hook handoff rule.
  prompt  UserPromptSubmit. Edits found here happened BETWEEN turns (the operator editing in
          Obsidian/Finder, Box sync, …). They are journaled as `phase: prompt` so the Stop hook
          does not blame the agent for them, and the baseline is refreshed. Silent.

Exit codes: 0 silent (nothing to say, or an internal error — fail-open); 2 validation failure.
"""
import sys
sys.dont_write_bytecode = True
import os
import subprocess
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import hooklib as H  # noqa: E402


def validate(rel_paths, added=None):
    """Run the skill validator on each changed ledger; return the concatenated failure report
    ('' when all valid or the validator is missing). `added` maps rel → IDs new in this write: those
    entries must carry OwnerSessionId/OwnerSessionUserName (1.4.0)."""
    if not os.path.exists(H.VALIDATOR):
        return ""
    reports = []
    for rel in rel_paths:
        path = os.path.join(H.PROJECT_ROOT, rel)
        if not os.path.exists(path):
            continue                                   # deleted ledger: nothing to validate
        cmd = [sys.executable, H.VALIDATOR, path]
        ids = sorted((added or {}).get(rel) or [])
        if ids:
            cmd += ["--require-owner", ",".join(ids)]
            if os.path.basename(rel).startswith("decisions"):
                cmd += ["--hil-ids", ",".join(ids)]        # 2.1.0: HIL rule enforced on new decisions
        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        except Exception as e:                         # never wedge on a tooling error
            H.log(f"track_edits: validator error on {rel}: {e}")
            continue
        if res.returncode != 0:
            reports.append(f"[{rel}]\n{(res.stdout or '') + (res.stderr or '')}".rstrip())
    return "\n".join(reports)


def foreign_shard_writes(changed, payload, token):
    """Writes by THIS session's tool call to a ledger file it does not own (1.7.0 partitioning):
    another session's shard or the legacy unsuffixed ledger. Only tool-call-named paths and, when no
    other session is active, any unnamed change count — an external change is not a violation."""
    named = H.paths_from_tool_input(payload)
    others = bool(H.other_active_sessions(payload))
    out = []
    for c in changed:
        st = H.shard_token(c["path"])
        if st is None or st == token or not token:
            continue
        mine = c["path"] in named or (not others and not c.get("synthetic"))
        if not mine:
            continue
        what = "legacy ledger (read-only since 1.7.0 — `ks ledger archive` moves it to the archive)" if st == "" else f"shard of session {st}"
        out.append(f"[{c['path']}] {what}")
    return "\n".join(out)


def lost_updates(changed, token):
    """Entries/tasks that disappeared in this write and must not have (lost-update guard):
      append-only ledgers   any removed EntryID — unless it now lives in archive/<same ledger>.yaml
      mutable ledgers       removed entries owned by ANOTHER session (own ones may be rewritten) — same exemption
      tasks.md              removed TaskIDs not present in archive/tasks.md (or legacy tasks-archive.md)
      archives              never lose an ID
    Returns a report string ('' when clean)."""
    out = []
    cache = {}

    def ids_in(rel):
        if rel not in cache:
            cache[rel] = H.ledger_ids(rel)
        return cache[rel]

    for c in changed:
        removed = c.get("removed_ids") or {}
        if not removed:
            continue
        cls = c.get("class") or ""
        rel = c["path"]
        if cls.startswith("archive:") or cls == "plan-archive":
            out.append(f"[{rel}] archive lost: " + ", ".join(sorted(removed)) + " (archives are append-only)")
            continue
        arch = H.archive_path_for(rel)
        archived = ids_in(arch) if arch else {}
        if cls == "plan":
            archived = dict(archived, **ids_in(f"{H.WORKAREA_REL}/tasks-archive.md"))
        if cls.startswith("ledger:"):
            kind = cls.split(":", 1)[1]
            if kind in H.APPEND_ONLY_LEDGERS:
                bad = {i: o for i, o in removed.items() if i not in archived}
            else:
                bad = {i: o for i, o in removed.items() if o and o != token and i not in archived}
            if bad:
                out.append(f"[{rel}] removed: " + ", ".join(f"{i} (session {o or 'legacy'})" for i, o in sorted(bad.items()))
                           + (f" — move them to {arch} first if archiving" if arch else ""))
        elif cls == "plan":
            bad = [i for i in removed if i not in archived]
            if bad:
                out.append(f"[{rel}] TaskIDs removed without archiving: " + ", ".join(sorted(bad)))
    return "\n".join(out)


def prompt_notice(payload, changed):
    """UserPromptSubmit: tell the model what changed since it last looked — configuration switched with
    `ks` (routing, operator, armed flag, config.toml) and files changed outside this session's tool
    calls (another session, `ks ledger archive`, an editor). '' when nothing happened."""
    lines = []
    try:
        lines += H.config_changes(payload)
    except Exception as e:
        H.log(f"prompt_notice: {type(e).__name__}: {e}")
    # At prompt time nothing in the diff can be this session's own tool call (PostToolUse already
    # journaled those), so every change is "outside": ks, an editor, another session.
    # new blockers since the last prompt: open issues and negative gates among the entries added
    try:
        neg = {("REVIEW", "FAIL"), ("TEST", "KO"), ("AUDIT", "NON-CONFORMANT"), ("APPROVAL", "NO-GO")}
        for c in changed:
            if (c.get("class") or "") != "ledger:events":
                continue
            ids = set((c.get("added_ids") or {}).keys()) | set((c.get("new_for_session") or {}).keys())
            if not ids:
                continue
            for eid, f in H.load_entries(os.path.join(H.PROJECT_ROOT, c["path"])):
                if eid in ids and isinstance(f, dict):
                    et, st = str(f.get("EventType")), str(f.get("Status"))
                    if et == "ISSUE" and st == "OPEN":
                        lines.append(f"New open issue {eid} “{str(f.get('Title', ''))[:60]}” on task {f.get('TaskID')}.")
                    elif (et, st) in neg:
                        lines.append(f"Gate failed: {et} {st} — {eid} “{str(f.get('Title', ''))[:60]}” on task {f.get('TaskID')} (blocked until a later positive gate).")
    except Exception as e:
        H.log(f"prompt_notice: blockers: {e}")
    ext = [c for c in changed if not (lines and c["path"] == H.MODELS_TOML_REL)]
    shard_news = [c for c in ext if H.shard_token(c["path"]) not in (None, "") and H.shard_token(c["path"]) != H.session_token(payload)]
    for c in shard_news:
        ids = list((c.get("new_for_session") or c.get("added_ids") or {}).keys())
        kind = (c.get("class") or "ledger:?").split(":", 1)[1]
        titles = []
        try:
            for eid, f in H.load_entries(os.path.join(H.PROJECT_ROOT, c["path"])):
                if eid in ids and isinstance(f, dict):
                    titles.append(f"{eid} “{str(f.get('Title', ''))[:50]}”")
        except Exception:
            pass
        who = H.shard_token(c["path"])
        rec = next((d for d in H.list_sessions() if d.get("token") == who), {})
        lines.append(f"Session {who}" + (f" ({rec.get('operator')})" if rec.get("operator") else "")
                     + f" added {len(ids)} {kind} entr{'y' if len(ids) == 1 else 'ies'}: " + "; ".join(titles[:4]) + (" …" if len(titles) > 4 else ""))
    ext = [c for c in ext if c not in shard_news]
    if ext:
        names = sorted({c["path"] for c in ext})
        owners = sorted({o for c in ext for o in (c.get("new_for_session") or {}).values() if o})
        lines.append(f"{len(names)} file(s) changed outside this session's tool calls: " + ", ".join(names[:6])
                     + (" …" if len(names) > 6 else "")
                     + (f" (session {', '.join(owners)})" if owners else "")
                     + " — re-read before editing them; STATE.md refreshes at the next turn end.")
    if not lines:
        return ""
    return "TKSfw — changed since your last prompt:\n" + "\n".join("• " + l for l in lines)


def lint_plan(rel_paths):
    """tasks_lint on changed plan files: (errors_report, warnings_report). Only the LIVE tasks.md is
    linted; tasks-archive.md is frozen history."""
    tool = os.path.join(H.VALIDATOR_DIR, "tasks_lint.py")
    if not os.path.exists(tool):
        return "", ""
    errs, warns = [], []
    for rel in rel_paths:
        if rel != f"{H.WORKAREA_REL}/tasks.md":
            continue                                   # archives are frozen history
        path = os.path.join(H.PROJECT_ROOT, rel)
        if not os.path.exists(path):
            continue
        try:
            res = subprocess.run([sys.executable, tool, path, "--json"], capture_output=True, text=True, timeout=30)
            data = json.loads(res.stdout or "{}")
        except Exception as e:
            H.log(f"track_edits: tasks_lint error on {rel}: {e}")
            continue
        if data.get("errors"):
            errs.append(f"[{rel}]\n  - " + "\n  - ".join(data["errors"]))
        if data.get("warnings"):
            warns.append(f"[{rel}] " + "; ".join(data["warnings"][:4]) + (" …" if len(data["warnings"]) > 4 else ""))
    return "\n".join(errs), "\n".join(warns)


def validate_agents(rel_paths):
    """Run the define-agent validator on each changed agent definition; '' when clean/missing."""
    if not os.path.exists(H.AGENT_VALIDATOR):
        return ""
    reports = []
    for rel in rel_paths:
        path = os.path.join(H.PROJECT_ROOT, rel)
        if not os.path.exists(path):
            continue
        try:
            res = subprocess.run([sys.executable, H.AGENT_VALIDATOR, path, "--models", H.MODELS_TOML],
                                 capture_output=True, text=True, timeout=30)
        except Exception as e:
            H.log(f"track_edits: agent validator error on {rel}: {e}")
            continue
        if res.returncode == 2:
            reports.append(f"[{rel}]\n{(res.stdout or '') + (res.stderr or '')}".rstrip())
    return "\n".join(reports)


def render_mirrors(rel_paths):
    """Render the Codex/Claude mirrors of validated agent sources. Advisory: returns a message when
    something could not be rendered ('' otherwise) — the write already happened, never block."""
    try:
        import agentlib
        res = agentlib.sync(check=False, only=[os.path.join(H.PROJECT_ROOT, r) for r in rel_paths])
    except Exception as e:
        H.log(f"track_edits: agent mirror rendering: {type(e).__name__}: {e}")
        return ""
    bad = [r for r in res if r[0] == "conflict"]
    if bad:
        return ("Agent mirrors not rendered — fix and re-save the source (or run sync_harness.py --models): "
                + "; ".join(f"{r[1]}: {r[2] if len(r) > 2 else ''}" for r in bad))
    return ""


def prune_mirrors(rel_paths):
    try:
        import agentlib
        for r in rel_paths:
            agentlib.remove_mirrors(os.path.splitext(os.path.basename(r))[0], False, [])
    except Exception as e:
        H.log(f"track_edits: agent mirror pruning: {type(e).__name__}: {e}")


def main():
    phase = "tool"
    if "--phase" in sys.argv:
        i = sys.argv.index("--phase")
        if i + 1 < len(sys.argv):
            phase = sys.argv[i + 1]
    H.guard()
    payload = H.read_payload()
    tool_name = payload.get("tool_name") if phase == "tool" else None
    tool_use_id = payload.get("tool_use_id") if phase == "tool" else None

    try:
        with H.locked():
            changed, first_run = H.record_changes(payload, phase, tool_name, tool_use_id)
    except Exception as e:
        H.log(f"track_edits({phase}): {type(e).__name__}: {e}")
        sys.exit(0)

    if phase == "prompt":
        notice = prompt_notice(payload, changed)
        if notice:
            H.emit(H.additional_context("UserPromptSubmit", notice))
        sys.exit(0)
    if phase != "tool" or first_run:
        sys.exit(0)

    ledgers = [c["path"] for c in changed
               if (c.get("class") or "").startswith(("ledger:", "archive:")) and c["kind"] != "deleted"]
    agents = [c["path"] for c in changed
              if H.AGENT_FILE_RE.match(c["path"]) and c["kind"] != "deleted"]
    deleted_agents = [c["path"] for c in changed
                      if H.AGENT_FILE_RE.match(c["path"]) and c["kind"] == "deleted"]
    if deleted_agents:
        prune_mirrors(deleted_agents)
    plans = [c["path"] for c in changed if c.get("class") == "plan" and c["kind"] != "deleted"]
    token = H.session_token(payload)
    foreign = foreign_shard_writes(changed, payload, token)
    lost = lost_updates(changed, token)
    if not ledgers and not agents and not plans and not lost and not foreign:
        sys.exit(0)
    messages = []
    if foreign:
        messages.append(
            "READ-ONLY LEDGER — this session may write only its own shards "
            f"(`<ledger>.{token or '<token>'}.yaml`); other sessions' shards and the legacy unsuffixed files are read-only. "
            "Restore the file you touched and put your entry in your shard:\n" + foreign)
    if lost:
        messages.append(
            "LOST UPDATE — this write removed entries that another session (or an earlier turn) recorded. "
            "Re-read the file and restore them; append-only ledgers never lose entries, tasks.md items move "
            "only to tasks-archive.md:\n" + lost)
    added = {c["path"]: list((c.get("added_ids") or {}).keys()) for c in changed
             if (c.get("class") or "").startswith("ledger:")}          # archive appends carry entries verbatim (legacy ok)
    plan_errors, plan_warnings = lint_plan(plans) if plans else ("", "")
    if plan_errors:
        messages.append(
            "Activity plan (tasks.md) validation FAILED — fix the line(s) before continuing — load the "
            f"yaml-log-entry skill (grammar: {os.path.join(os.path.dirname(H.SCHEMAS_MD), 'tasks.md')}). Expected: "
            "'- [ ] <TaskID> <Title> - <AgentName> : <OPEN|IN-PROGRESS|WAITING-FOR|COMPLETED> <YYYY-MM-DD hh:mm:ss>' "
            "([x] iff COMPLETED; completed leaf tasks add [ev:<EventID>]):\n" + plan_errors)
    report = validate(ledgers, added) if ledgers else ""
    if report:
        messages.append(
            "Workarea YAML validation FAILED — fix the entry before continuing "
            f"— load the yaml-log-entry skill (new entries carry OwnerSessionId: {token or '<session token>'} and "
            "OwnerSessionUserName): schemas in "
            f"{H.SCHEMAS_MD}, ID minting in {os.path.join(H.VALIDATOR_DIR, 'new_entry_id.py')}:\n" + report)
    areport = validate_agents(agents) if agents else ""
    if areport:
        messages.append(
            "Agent definition validation FAILED — fix the file before continuing — load the "
            f"define-agent skill (convention: {os.path.join(os.path.dirname(H.AGENT_VALIDATOR), '..', 'references', 'naming.md')}); "
            "the harness mirrors are rendered automatically once the file is valid; log the change in changes.yaml:\n" + areport)
    if not messages:
        advisory = render_mirrors(agents) if agents else ""
        if plan_warnings:
            advisory = (advisory + "\n" if advisory else "") + \
                "Activity plan: evidence-of-closing — " + plan_warnings + \
                " (a COMPLETED leaf cites the events.yaml entry that proves it: [ev:<EventID>])."
        if advisory:
            H.emit({"systemMessage": advisory})
        sys.exit(0)
    sys.stderr.write("\n".join(messages) + "\n")
    sys.exit(2)


if __name__ == "__main__":
    main()
